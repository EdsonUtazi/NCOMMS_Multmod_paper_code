###Example script used for classifying clusters as slum and non-slum areas - Nigeria

library(tidyverse)
library(foreign)

setwd(".../Nigeria")
nig_house <- read.dta(".../NGHR7AFL.DTA",
                      convert.factors=TRUE)

#Select and rename variables
HH1 <- nig_house %>%
  select(hv001, hv002, hv201, hv202, hv205, hv225, hv238, hv213, hv214, hv215, hv009, hv216, hv025, hv270) %>%
  rename(cluster = hv001, hh_no = hv002, source_drink_water = hv201, source_nondrink_water = hv202,
         type_of_toilet = hv205, share_toilet = hv225, no_HH_sharing_toilet = hv238,
         floor_mat = hv213, wall_mat = hv214, roof_mat = hv215, hh_size = hv009, no_of_sleep_rooms = hv216,
         urban=hv025, hh_wealth = hv270)

#Recode variables
HH2 <- HH1 %>%
  #filter(age ==1, alive == "yes") %>% #Filter by urban rural
  mutate(urban = recode(urban,
                        "rural" = 0,
                        "urban" = 1)) %>%
  mutate(source_drink_water = recode(source_drink_water,       ##This is the main variable
                                        "piped into dwelling" = 0,
                                        "piped to yard/plot" = 0,
                                        "piped to neighbor" = 0,
                                        "public tap/standpipe" = 0,
                                        "tube well or borehole" = 0,
                                        "protected well" = 0,
                                        "unprotected well" = 1,
                                        "protected spring" = 0,
                                        "unprotected spring" = 1,
                                        "river/dam/lake/ponds/stream/canal/irrig" = 1,
                                        "rainwater" = 0,
                                        "tanker truck" = 1,
                                        "cart with small tank" = 1,
                                        "bottled water" = 1,
                                        "sachet water" = 1,
                                        "other" = 1)) %>%
  mutate(water_var = if_else(source_drink_water == 1 & !is.na(source_drink_water), 1,0 )) %>%
  mutate(type_of_toilet = recode(type_of_toilet,
                                 "flush to piped sewer system" = 0,
                                 "flush to septic tank" = 0,
                                 "flush to pit latrine" = 0,
                                 "flush to somewhere else" = 0,
                                 "flush, don't know where" = 0,
                                 "ventilated improved pit latrine (vip)"= 0,
                                "pit latrine with slab" = 0,
                                "pit latrine without slab/open pit" = 1,
                                "no facility/bush/field" = 1,
                                "composting toilet" = 0,
                                "bucket toilet" = 1,
                                "hanging toilet/latrine" = 1,
                                "other" = 1)) %>%
  mutate(toilet_var = if_else(type_of_toilet == 1 | (no_HH_sharing_toilet != 2 & !is.na(no_HH_sharing_toilet)), 1, 0)) %>%
  mutate(floor_mat_var = recode(floor_mat,
                                       "earth/sand" = 1,
                                       "dung" = 1,
                                       "wood planks" = 1,
                                       "palm/bamboo" = 1,
                                       "parquet or polished wood" = 0,
                                       "vinyl or asphalt strips"= 0,
                                       "ceramic tiles" = 0,
                                       "cement" = 0,
                                       "carpet" = 0,
                                       "other" = 0)) %>%
  mutate(persons_per_room = hh_size/no_of_sleep_rooms) %>%
  mutate(overcrowd_var = if_else(persons_per_room > 3, 1,0)) %>%
  mutate(score = water_var + toilet_var + floor_mat_var + overcrowd_var) %>%
  mutate(slum_score = if_else(score >= 2, 1,0 ))    #Note score is now 2


###Number of households
min_hh_no <- 10  #Minimum number of households required to make a slum classification
Clust_no <- unique(HH2$cluster)
Urban_clust <- rep(0, length(Clust_no))
Urban_slum_50 <- rep(0, length(Clust_no))
Urban_slum_75 <- rep(0, length(Clust_no))
len <- rep(0, length(Clust_no))
for (i in 1:length(Clust_no)){
  ind <- which(HH2$cluster==Clust_no[i])
  len[i] <- length(na.omit(HH2$slum_score[ind]))
  if (HH2$urban[ind[1]]==1) Urban_clust[i] <- 1
  if (Urban_clust[i]==1 && len[i]>=min_hh_no) {
    perc <- 100*(sum(na.omit(HH2$slum_score[ind]))/length(na.omit(HH2$slum_score[ind])))
    if (perc > 75) Urban_slum_75[i] = 1  #Used in the analysis
    if (perc > 50) Urban_slum_50[i] = 1
  }
}

dat_out <- data.frame(Cluster=Clust_no, Urban = Urban_clust, Urban_slum_50 = Urban_slum_50, Urban_slum_75 = Urban_slum_75)
write.csv(dat_out, "nig_urban_slum_class.csv")







