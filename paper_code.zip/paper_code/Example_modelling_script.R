#####Example modelling script for DTP1, DTP3 and MCV1 for Nigeria

library(tidyverse)
library(gtools)
library(INLA)
library(janitor)
library(questionr)
library(summarytools)
library(gmodels)
library(car)
library(dplyr)

set.seed(500)

setwd(".../Nigeria")

#Read in recoded DHS data
dhs_dat <- read_csv("nga_dhs_recoded.csv")

#Read in geospatial data - travel time
geos_dat <- read_csv("nga_zerodose_extractions_combined.csv")

#Read in conflict and slum data
slum_dat <- read_csv("nig_urban_slum_class.csv")
slum_dat <- slum_dat %>%
  select(Cluster, Urban, Urban_slum_50, Urban_slum_75) %>%
  rename(DHSCLUST = Cluster, Urban_test = Urban)

#Add conflict and slum data to other geospatial data
geos_dat <- geos_dat %>%
  left_join(slum_dat, by = "DHSCLUST")

#Select relevant information from geospatial data
geos_dat1 <-geos_dat %>%    
  select(DHSCLUST, nga_Accessibility, nga_conflict_broadDef, Urban_slum_75) %>%
  rename(cluster = DHSCLUST, nga_ConflictPresence =nga_conflict_broadDef, nga_SlumPresence= Urban_slum_75)

#Merge geospatial data with DHS data
nig_full_join <- dhs_dat%>%
  inner_join(geos_dat1, by = "cluster")      

dhs_dat1 <- data.frame(nig_full_join)

###Grouping of AccessMean - travel time to urban areas
dhs_dat1$AccessMean_group <- quantcut(dhs_dat1$nga_Accessibility, q=3, na.rm=TRUE)
dhs_dat1$AccessMean_group <- as.factor(dhs_dat1$AccessMean_group); levels(dhs_dat1$AccessMean_group) <- c("0 - 9.86", "9.87 - 32.1", "32.2 - 592")
dhs_dat1$AccessMean_group <- relevel(dhs_dat1$AccessMean_group, ref = "32.2 - 592")

#Percentage of missing data
freq.na(dhs_dat1[,c(9:49)])

#####Frequency tables
##Asign labels first and declare each var as a factor
dhs_dat1$dpt1_crude <- as.factor(dhs_dat1$dpt1_crude); levels(dhs_dat1$dpt1_crude) <- c("no/don't know", "yes")
dhs_dat1$dpt2_crude <- as.factor(dhs_dat1$dpt2_crude); levels(dhs_dat1$dpt2_crude) <- c("no/don't know", "yes")
dhs_dat1$dpt3_crude <- as.factor(dhs_dat1$dpt3_crude); levels(dhs_dat1$dpt3_crude) <- c("no/don't know", "yes")
dhs_dat1$mcv1 <- as.factor(dhs_dat1$mcv1); levels(dhs_dat1$mcv1) <- c("no/don't know", "yes")
dhs_dat1$sex_child <- as.factor(dhs_dat1$sex_child); levels(dhs_dat1$sex_child) <- c("male", "female")
dhs_dat1$bord <- as.factor(dhs_dat1$bord); levels(dhs_dat1$bord) <- c("1-2", "3-5", ">5")
dhs_dat1$birth_int <- as.factor(dhs_dat1$birth_int); levels(dhs_dat1$birth_int) <- c("< 36 months", ">= 36 months")
dhs_dat1$health_card_doc  <- Recode(dhs_dat1$health_card_doc , recodes = "0=0; 1=1; 2=1")
dhs_dat1$health_card_doc <- as.factor(dhs_dat1$health_card_doc)
levels(dhs_dat1$health_card_doc) <- c("no", "yes, (un)seen")
dhs_dat1$sba <- as.factor(dhs_dat1$sba); levels(dhs_dat1$sba) <- c("no", "yes")
dhs_dat1$anc <- as.factor(dhs_dat1$anc); levels(dhs_dat1$anc) <- c("no", "1-3", ">=4")
dhs_dat1$birth_quarter <- as.factor(dhs_dat1$birth_quarter); levels(dhs_dat1$birth_quarter) <- c("Jan-Mar", "Apr-Jun", "Jul-Sep", "Oct-Dec")
dhs_dat1$tt_bbirth <- as.factor(dhs_dat1$tt_bbirth); levels(dhs_dat1$tt_bbirth) <- c("no/don't know", "1-2", "3-4", ">=5")
dhs_dat1$pnc <- as.factor(dhs_dat1$pnc); levels(dhs_dat1$pnc) <- c("no/don't know", "yes")
dhs_dat1$vit_a_recent <- as.factor(dhs_dat1$vit_a_recent); levels(dhs_dat1$vit_a_recent) <- c("no/don't know", "yes")
dhs_dat1$sex_hh <- as.factor(dhs_dat1$sex_hh); levels(dhs_dat1$sex_hh) <- c("female", "male")
dhs_dat1$m_age_grp <- as.factor(dhs_dat1$m_age_grp); levels(dhs_dat1$m_age_grp) <- c("15-19", "20-29", "30-39", "40-49")
dhs_dat1$marital <- as.factor(dhs_dat1$marital); levels(dhs_dat1$marital) <- c("never in union", "married/with partner", "divorced/widowed/separated")
dhs_dat1$decision <- as.factor(dhs_dat1$decision); levels(dhs_dat1$decision) <- c("husband/partner/others", "mother/mother,husband,partner")
dhs_dat1$Prob_get_advice <- as.factor(dhs_dat1$Prob_get_advice); levels(dhs_dat1$Prob_get_advice) <- c("had problem", "had no problem")
dhs_dat1$educ <- as.factor(dhs_dat1$educ); levels(dhs_dat1$educ) <- c("none", "primary", "sec./higher")

dhs_dat1$religion_w  <- Recode(dhs_dat1$religion_w , recodes = "0=0; 1=1; 2=1")
dhs_dat1$religion_w <- as.factor(dhs_dat1$religion_w); levels(dhs_dat1$religion_w) <- c("Islam", "Christian/Trad./others")

dhs_dat1$media <- as.factor(dhs_dat1$media); levels(dhs_dat1$media) <- c("no", "yes")
dhs_dat1$phone_internet <- as.factor(dhs_dat1$phone_internet); levels(dhs_dat1$phone_internet) <- c("no", "yes")
dhs_dat1$land <- as.factor(dhs_dat1$land); levels(dhs_dat1$land) <- c("no", "alone or jointly")
dhs_dat1$mal_know <- as.factor(dhs_dat1$mal_know); levels(dhs_dat1$mal_know) <- c("no", "yes")
dhs_dat1$occup <- as.factor(dhs_dat1$occup); levels(dhs_dat1$occup) <- c("agric.", "clerical/sales/services", "prof./tech./mgr.", "(un)skilled manual/other")

dhs_dat1$employed_12m  <- Recode(dhs_dat1$employed_12m , recodes = "0=1; 1=0")
dhs_dat1$employed_12m <- as.factor(dhs_dat1$employed_12m); levels(dhs_dat1$employed_12m) <- c("no", "yes(currently/in the past 1 year)")

dhs_dat1$insurance <- as.factor(dhs_dat1$insurance); levels(dhs_dat1$insurance) <- c("no", "yes")
dhs_dat1$own_bednet <- as.factor(dhs_dat1$own_bednet); levels(dhs_dat1$own_bednet) <- c("no", "yes")
dhs_dat1$u5_bednet <- as.factor(dhs_dat1$u5_bednet); levels(dhs_dat1$u5_bednet) <- c("no/no net in household", "some/all children")
dhs_dat1$ethnicity <- as.factor(dhs_dat1$ethnicity); levels(dhs_dat1$ethnicity) <- c("Hausa/Fulani", "Yoruba", "Igbo", "Others")
dhs_dat1$wealth <- as.factor(dhs_dat1$wealth); levels(dhs_dat1$wealth) <- c("Poorest", "Middle", "Richest")
dhs_dat1$bank <- as.factor(dhs_dat1$bank); levels(dhs_dat1$bank) <- c("no", "yes")
dhs_dat1$hhsize <- as.factor(dhs_dat1$hhsize); levels(dhs_dat1$hhsize) <- c("large (>=9)", "medium (5-8)", "small (<=4)")
dhs_dat1$length_stay <- as.factor(dhs_dat1$length_stay); levels(dhs_dat1$length_stay) <- c("<1y/visitor", "1-3y", "4-5y", ">5y/always")
dhs_dat1$urban <- as.factor(dhs_dat1$urban); levels(dhs_dat1$urban) <- c("rural", "urban")
dhs_dat1$region <- as.factor(dhs_dat1$region); levels(dhs_dat1$region) <- c("NW", "NE", "NC", "SE", "SS", "SW")

dhs_dat1$nga_SlumPresence <- as.factor(dhs_dat1$nga_SlumPresence); levels(dhs_dat1$nga_SlumPresence) <- c("no", "yes")
dhs_dat1$nga_SlumPresence <- relevel(dhs_dat1$nga_SlumPresence, ref = "yes")

dhs_dat1$nga_ConflictPresence <- as.factor(dhs_dat1$nga_ConflictPresence); levels(dhs_dat1$nga_ConflictPresence) <- c("no", "yes")
dhs_dat1$nga_ConflictPresence <- relevel(dhs_dat1$nga_ConflictPresence, ref = "yes")

######################################################################
#Create new residence variable - not included in multivariate analyses
dhs_dat1$residence <- as.character(dhs_dat1$urban)
dhs_dat1$residence[dhs_dat1$nga_SlumPresence=="yes"] <- "slum"
dhs_dat1$residence <- as.factor(dhs_dat1$residence)
dhs_dat1$residence <- relevel(dhs_dat1$residence, ref = "urban")
table(dhs_dat1$residence)
#####################################################################

#Delete variables with >19% missing data - occup, birth_int
#Delete variables with > 5% missing data - decision, pnc
dhs_dat1 <- dhs_dat1[,-c(15, 21, 26, 34)]

#Full data has 6036 rows; complete cases have 5704; 332 records missing
#Other vars with missing data are - anc 233(4%); tt_birth 233(4%); u5_bednet 99 (2%)
dhs_dat1_full <- dhs_dat1
dhs_dat1 <- dhs_dat1[complete.cases(dhs_dat1),]

#Percentage of missing data
freq.na(dhs_dat1_full)


###########################################################################################################
####MCV1

###Some functions for bivariate analysis
#(Note that bivariate analyses were done using STATA, the functions
#includd here are for additional checks)
 
#Names of covariates
covnames <- names(dhs_dat1)[c(9:11,13:41,43:46)]

#Chi-square tests
chisq.out <- data.frame(Covariate = character(), stat = numeric(), pvalue = numeric(), sig = character())

for (i in 1:length(covnames)){
  ll <- which(names(dhs_dat1)==covnames[i])
  ct <- CrossTable(dhs_dat1[,ll], dhs_dat1$mcv1, chisq = TRUE, prop.c=FALSE, prop.r=FALSE,
                   prop.t=FALSE, prop.chisq=FALSE)
  sig <- "no"; if (ct$chisq$p.value < 0.05) sig <- "yes"
  lev <- levels(dhs_dat1[,ll])
  if (length(lev) == 2) chisq.out[i,] <- c(covnames[i], as.numeric(ct$chisq$statistic), ct$chisq$p.value, sig)
  if (length(lev) > 2) chisq.out[i,] <- c(covnames[i], as.numeric(ct$chisq$statistic), ct$chisq$p.value, sig)
}

#Bivariate logistic regression
logmod.out <- data.frame(Covariate = character(), min.pvalue = character())

for (i in 1:length(covnames)){
  form <- paste("mcv1", "~", covnames[i])
  log.mod <- glm(form, data = dhs_dat1, family="binomial")
  print(summary(log.mod))
  print(exp(cbind(OR = coef(log.mod), confint(log.mod))))
  sig <- "no"
  if (min(summary(log.mod)$coefficients[-1,4]) < 0.05) sig <- "yes"
  logmod.out[i,] <- c(covnames[i], sig)
}


#Check for multicollinearity
#Excluded region due to multicollinearity
#Excluded dpt2_crude - not needed
#Excluded "own_bednet" & "u5_bednet" due to redundancy (mal_know already present in the model)
covnames1 <- c("sex_child", "bord", "sba", "anc", 
               "birth_quarter", "tt_bbirth",  "sex_hh", "m_age_grp", "marital",
               "Prob_get_advice", "educ", "religion_w", "media", "phone_internet", "land",
               "mal_know", "employed_12m", "insurance", "ethnicity", "wealth", "bank",
               "hhsize", "urban", "length_stay",
               "nga_SlumPresence", "nga_ConflictPresence", "AccessMean_group")

form <- paste("mcv1", "~", paste(covnames1, collapse="+"))
log.mod <- glm(form, data = dhs_dat1, family="binomial")
summary(log.mod)
exp(cbind(OR = coef(log.mod), confint(log.mod))) ## odds ratios and 95% CI
vif(log.mod)


##Multivariate analysis begins here

#Convert stratification variable to numbers
dhs_dat1$strat_num <- as.numeric(as.factor(dhs_dat1$strat))

#Note that the clusters are uniquely numbered

#Create unique labels for households within clusters
dhs_dat1$clust_hh <- paste(dhs_dat1$cluster, dhs_dat1$hh_no, sep=".")


##############MODEL FITTING FOR MCV1
#Re-convert mcv1 to numeric for model-fitting using inla
dhs_dat1$mcv1a <- as.numeric(dhs_dat1$mcv1)
dhs_dat1$mcv1a <- recode(dhs_dat1$mcv1a, recodes="1=0; 2=1; else=NA")


#NOTE NEW PRIOR
prec.prior1 <- list(prec = list(param = c(0.1, 0.1)))
control.fixed = list(mean=0, prec=1/1000, mean.intercept=0, prec.intercept=1/1000) #Priors on regression coefficients


####Model-fitting
form <- mcv1a ~ sex_child + bord + sba + anc + birth_quarter + tt_bbirth +
  sex_hh + m_age_grp + marital + Prob_get_advice + educ + religion_w + media + phone_internet + land + mal_know +
  employed_12m + insurance + ethnicity + wealth + bank + hhsize +  length_stay + urban +
  nga_SlumPresence + nga_ConflictPresence + AccessMean_group + f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.mcv1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed)

summary(mod.fit.mcv1)

#Odds ratios
out <- exp(mod.fit.mcv1$summary.fixed[, c(1,3,4,5)])
out
out.mcv1 <- data.frame(out)
write.csv(out.mcv1, "nga_mcv1_out.csv")

#Observed vs fitted
fitted.mean <- mod.fit.mcv1$summary.fitted.values$mean
fitted.median <- mod.fit.mcv1$summary.fitted.values$"0.5quant"
obs <- dhs_dat1$mcv1a
out.mcv1.1 <- data.frame(obs=obs, fitted.mean=fitted.mean, fitted.median=fitted.median)
write.csv(out.mcv1.1, "nga_mcv1_fitted_obs.csv")




#### Multivariate analysis for DTP1
#Check for multicollinearity
covnames1 <- c("sex_child", "bord", "sba", "anc", 
               "birth_quarter", "tt_bbirth",  "sex_hh", "m_age_grp", "marital",
               "Prob_get_advice", "educ", "religion_w", "media", "phone_internet", "land",
               "mal_know", "employed_12m", "insurance", "ethnicity", "wealth", "bank",
               "hhsize", "urban", "length_stay",
               "nga_SlumPresence", "nga_ConflictPresence", "AccessMean_group")

form <- paste("dpt1_crude", "~", paste(covnames1, collapse="+"))
log.mod <- glm(form, data = dhs_dat1, family="binomial")
summary(log.mod)
exp(cbind(OR = coef(log.mod), confint(log.mod))) ## odds ratios and 95% CI
vif(log.mod)


#Re-convert mcv1 to numeric for model-fitting using inla
dhs_dat1$dpt1_crudea <- as.numeric(dhs_dat1$dpt1_crude)
dhs_dat1$dpt1_crudea <- recode(dhs_dat1$dpt1_crudea, recodes="1=0; 2=1; else=NA")

####Model-fitting
form <- dpt1_crudea ~  sex_child + bord + sba + anc + birth_quarter + tt_bbirth +
  sex_hh + m_age_grp + marital + Prob_get_advice + educ + religion_w + media + phone_internet + land + mal_know +
  employed_12m + insurance + ethnicity + wealth + bank + hhsize + urban + length_stay + nga_SlumPresence +
  nga_ConflictPresence +AccessMean_group + f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.dpt1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                     control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed)

summary(mod.fit.dpt1)

#odds ratios
out <- exp(mod.fit.dpt1$summary.fixed[, c(1,3,4,5)])
out
out.dtp1 <- data.frame(out)
write.csv(out.dtp1, "nga_dtp1_out.csv")

#Observed vs predicted
fitted.mean <- mod.fit.dpt1$summary.fitted.values$mean
fitted.median <- mod.fit.dpt1$summary.fitted.values$"0.5quant"
obs <- dhs_dat1$dpt1_crudea
out.dpt1.1 <- data.frame(obs=obs, fitted.mean=fitted.mean, fitted.median=fitted.median)
write.csv(out.dpt1.1, "nga_dpt1_fitted_obs.csv")


#### Multivariate analysis for DTP3
#Check for multicollinearity
covnames1 <- c("sex_child", "bord", "sba", "anc", 
               "birth_quarter", "tt_bbirth",  "sex_hh", "m_age_grp", "marital",
               "Prob_get_advice", "educ", "religion_w", "media", "phone_internet", "land",
               "mal_know", "employed_12m", "insurance", "ethnicity", "wealth", "bank",
               "hhsize", "urban", "length_stay",
               "nga_SlumPresence", "nga_ConflictPresence", "AccessMean_group")

form <- paste("dpt3_crude", "~", paste(covnames1, collapse="+"))
log.mod <- glm(form, data = dhs_dat1, family="binomial")
summary(log.mod)
exp(cbind(OR = coef(log.mod), confint(log.mod))) ## odds ratios and 95% CI
vif(log.mod)


#Re-convert mcv1 to numeric for model-fitting using inla
dhs_dat1$dpt3_crudea <- as.numeric(dhs_dat1$dpt3_crude)
dhs_dat1$dpt3_crudea <- recode(dhs_dat1$dpt3_crudea, recodes="1=0; 2=1; else=NA")

####Model-fitting
form <- dpt3_crudea ~  sex_child + bord + sba + anc + birth_quarter + tt_bbirth +
  sex_hh + m_age_grp + marital + Prob_get_advice + educ + religion_w + media + phone_internet + land + mal_know +
  employed_12m + insurance + ethnicity + wealth + bank + hhsize + urban + length_stay + nga_SlumPresence +
  nga_ConflictPresence +AccessMean_group + f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.dpt3 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                     control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed)

summary(mod.fit.dpt3)

#odds ratios
out <- exp(mod.fit.dpt3$summary.fixed[, c(1,3,4,5)])
out
out.dtp3 <- data.frame(out)
write.csv(out.dtp3, "nga_dtp3_out.csv")

#Observed vs predicted
fitted.mean <- mod.fit.dpt3$summary.fitted.values$mean
fitted.median <- mod.fit.dpt3$summary.fitted.values$"0.5quant"
obs <- dhs_dat1$dpt3_crudea
out.dpt3.1 <- data.frame(obs=obs, fitted.mean=fitted.mean, fitted.median=fitted.median)
write.csv(out.dpt3.1, "nga_dpt3_fitted_obs.csv")


######Write combined results
out.full <- data.frame(out.mcv1, out.dtp1, out.dtp3)
colnames(out.full) <- c("mcv1_mean", "mcv1_low", "mcv1_median", "mcv1_high",
                        "dtp1_mean", "dtp1_low", "dtp1_median", "dtp1_high",
                        "dtp3_mean", "dtp3_low", "dtp3_median", "dtp3_high")
write.csv(out.full, "nga_results_OR.csv")



######Bivariate analyses using the key community variables - conflict, urban slum and travel time (accessibility)
###
form <- paste("mcv1", "~", "nga_ConflictPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
conf.mcv1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt1_crude", "~", "nga_ConflictPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
conf.dtp1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt3_crude", "~", "nga_ConflictPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
conf.dtp3 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

###
form <- paste("mcv1", "~", "nga_SlumPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
slum.mcv1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt1_crude", "~", "nga_SlumPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
slum.dtp1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt3_crude", "~", "nga_SlumPresence")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
slum.dtp3 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

###
form <- paste("mcv1", "~", "AccessMean_group")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
acc.mcv1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt1_crude", "~", "AccessMean_group")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
acc.dtp1 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

form <- paste("dpt3_crude", "~", "AccessMean_group")
log.mod <- glm(form, data = dhs_dat1, family="binomial")
acc.dtp3 <- exp(cbind(OR = coef(log.mod), confint(log.mod)))

out1 <- c(conf.mcv1[2,], conf.dtp1[2,], conf.dtp3[2,])
out2 <- c(slum.mcv1[2,], slum.dtp1[2,], slum.dtp3[2,])
out3 <- c(acc.mcv1[2,], acc.dtp1[2,], acc.dtp3[2,])
out4 <- c(acc.mcv1[3,], acc.dtp1[3,], acc.dtp3[3,])

out <- rbind(out1, out2, out3, out4)
colnames(out) <- c("mcv1_OR", "mcv1_low", "mcv1_up", "dtp1_OR", "dtp1_low", "dtp1_up", "dtp3_OR", "dtp3_low", "dtp3_up")
rownames(out) <- c("Conflict (no)", "Slum (no)", "Travel time (low)", "Travel time (medium)")
write.csv(out, "nga_results_bivariate_community_vars.csv")


