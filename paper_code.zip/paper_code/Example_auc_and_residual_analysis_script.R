########Example script for residual analysis and calculating the AUC statistic
########Preceding functions can be found in the modelling script
######## The calculations shown here are for MCV1 only

library(tidyverse); library(gtools); library(INLA)
library(janitor); library(questionr); library(summarytools)
library(gmodels); library(car); library(dplyr); library(pROC)

set.seed(500)

setwd(".../Nigeria")

####See modelling script for preceding functions

###MCV1
####Full model with all covariates included versus reduced model excluded only the key community variables

####Full model 
form <- mcv1a ~ sex_child + bord + sba + anc + birth_quarter + tt_bbirth +
  sex_hh + m_age_grp + marital + Prob_get_advice + educ + religion_w + media + phone_internet + land + mal_know +
  employed_12m + insurance + ethnicity + wealth + bank + hhsize +  length_stay + urban +
  nga_SlumPresence + nga_ConflictPresence + AccessMean_group + 
  f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.mcv1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed, 
                control.compute=list(dic=TRUE, waic=TRUE))

#AUC 
fitted.mean <- mod.fit.mcv1$summary.fitted.values$mean
fitted.median <- mod.fit.mcv1$summary.fitted.values$"0.5quant"
obs <- dhs_dat1$mcv1a
g <- roc(obs ~ fitted.mean, print.auc = TRUE) # calculate the C statistics
auc(g) # extract AUC value 
ci.auc(g, method="bootstrap") # extract 95% CI for AUC value

var.strat <- 1/mod.fit.mcv1$summary.hyperpar[1,1]
var.clust <- 1/mod.fit.mcv1$summary.hyperpar[2,1]
var.hh    <- 1/mod.fit.mcv1$summary.hyperpar[3,1]

#VPC
var.strat/(var.strat + var.clust + var.hh + 3.29) #Stratum
var.clust/(var.strat + var.clust + var.hh + 3.29) #Cluster
var.hh/(var.strat + var.clust + var.hh + 3.29)    #Household

Tot2 <- (var.strat + var.clust + var.hh + 3.29)

#Reduced model
form <- mcv1a ~ sex_child + bord + sba + anc + birth_quarter + tt_bbirth +
  sex_hh + m_age_grp + marital + Prob_get_advice + educ + religion_w + media + phone_internet + land + mal_know +
  employed_12m + insurance + ethnicity + wealth + bank + hhsize +  length_stay + urban +
  #nga_SlumPresence + nga_ConflictPresence + AccessMean_group + 
  f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.mcv1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                     control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed, 
                     control.compute=list(dic=TRUE, waic=TRUE))

var.strat <- 1/mod.fit.mcv1$summary.hyperpar[1,1]
var.clust <- 1/mod.fit.mcv1$summary.hyperpar[2,1]
var.hh    <- 1/mod.fit.mcv1$summary.hyperpar[3,1]

Tot1 <- (var.strat + var.clust + var.hh + 3.29)

#PCV
PCV <- ((Tot1 - Tot2)/Tot1)*100
PCV





####Model including only the key community variables versus no-covariate model

#Model including only the key community variables
form <- mcv1a ~ nga_SlumPresence + nga_ConflictPresence + AccessMean_group + 
  f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.mcv1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                     control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed, 
                     control.compute=list(dic=TRUE, waic=TRUE))


var.strat <- 1/mod.fit.mcv1$summary.hyperpar[1,1]
var.clust <- 1/mod.fit.mcv1$summary.hyperpar[2,1]
var.hh    <- 1/mod.fit.mcv1$summary.hyperpar[3,1]

Tot2 <- (var.strat + var.clust + var.hh + 3.29)


#No-covariate model
form <- mcv1a ~ f(strat_num, model="iid", hyper = prec.prior1) + #Unique stratum IDs
  f(cluster, model="iid",  hyper = prec.prior1) +   #Unique cluster IDs
  f(clust_hh, model="iid",  hyper = prec.prior1)  #Unique household IDs

mod.fit.mcv1 <- inla(as.formula(form), family="binomial", data=dhs_dat1, Ntrials=1,
                     control.predictor = list(compute = TRUE, link=1), control.fixed = control.fixed, 
                     control.compute=list(dic=TRUE, waic=TRUE))


var.strat <- 1/mod.fit.mcv1$summary.hyperpar[1,1]
var.clust <- 1/mod.fit.mcv1$summary.hyperpar[2,1]
var.hh    <- 1/mod.fit.mcv1$summary.hyperpar[3,1]

#PCV
Tot1 <- (var.strat + var.clust + var.hh + 3.29)
PCV <- ((Tot1 - Tot2)/Tot1)*100
PCV

