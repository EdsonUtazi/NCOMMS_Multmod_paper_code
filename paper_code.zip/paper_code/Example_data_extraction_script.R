####Data extraction script for Nigeria

library(tidyverse)
library(foreign)

setwd(".../Nigeria")


nig_child <- read.dta(".../NGKR7AFL.DTA",
                      convert.factors=TRUE)
nig_indi = read.dta(".../NGIR7AFL.DTA",
                    convert.factors=TRUE)
nig_house <- read.dta(".../NGHR7AFL.DTA",
                      convert.factors=TRUE)

#Make variable names unique in the women's file by prefixing all variable names with w
colnames(nig_indi)<- paste("w",colnames(nig_indi), sep = "")
nig_indi<- nig_indi %>% 
  mutate(clus_hhid = paste(wv001, wv002, sep = "_"),
         caseid = paste(clus_hhid, wv003, sep = "_"))

#Create unique ids by combining cluster and household ids
nig_house<- nig_house %>% 
  mutate(clus_hhid = paste(hv001, hv002, sep = "_"))
nig_child<- nig_child %>% 
  mutate(clus_hhid = paste(v001, v002, sep = "_"),
         caseid = paste(clus_hhid, v003, sep = "_"))

#Join children, women and household data
nig_join <- nig_child %>% 
  left_join(nig_house, by = "clus_hhid") %>% 
  left_join(nig_indi, by = "caseid")

rm(nig_indi,nig_house,nig_child)

#Select and rename variables
nig_sel <- nig_join %>% 
  select(v001, v002, v003, midx, hv005, v005, v023,
         b8, b5, b4, b1,
         h3, h5, h7, h9,
         m3a, m3b, m3c,
         v157, v158, v159,
         wv106, bord, hv025,
         hv270, hv024, b11,
         v714, v717, wv170, h33, h1a, wv130, hv219, v131, 
         v467b, v467c, v467d, v467f, m70, wv731, v459, 
         m1, m14, wv106, v501, hv009, wv012, v481, wv745b, v460, wv104, 
         wv743a, wv743d, wv743b, wv169a, wv170, wv171a, wv731, ws1108ai, ws1108ba,
         hw8, hw11, hw5) %>%
  rename(cluster = v001, hh_no = v002, resp_no = v003, wt_h=hv005, wt_w=v005, strat = v023,
         age = b8, alive = b5, sex_child=b4, urban=hv025,
         dpt1 = h3, dpt2 = h5, dpt3 = h7, mcv1 = h9, birth_month=b1,
         doctor = m3a, nurse = m3b, midwive = m3c,
         newspaper = v157, radio = v158, tv = v159,
         educ = wv106, region=hv024, birth_int=b11,
         wealth = hv270, bank=wv170, vit_a_recent=h33, health_card_doc=h1a,
         employ = v714, occup = v717, pnc=m70, employed_12m=wv731, 
         m_age_w=wv012, hhsize=hv009, marital=v501, anc=m14, tt_bbirth=m1,
         religion_w=wv130, sex_hh=hv219, ethnicity=v131,
         decide_health=wv743a, decide_visit=wv743d, decide_purchase=wv743b,
         m_phone=wv169a, internet=wv171a,
         mal_cure=ws1108ai, mal_death=ws1108ba, insurance=v481, land=wv745b, 
         own_bednet=v459, u5_bednet=v460, length_stay=wv104,
         under_wt=hw8, wasting=hw11, stunting=hw5)

#String matches in length of stay 
always<- "^always$"
visitor<-"^visitor$"

#Replace strings in anc field and convert to numreic
nig_sel$anc[nig_sel$anc == "no antenatal visits"]<- 0
nig_sel$anc[nig_sel$anc == "don't know"]<- 0    #I changed this from NA to 0
nig_sel$anc<-as.numeric(nig_sel$anc)


#Recode variables
nig <- nig_sel %>%
  filter(age ==1, alive == "yes") %>% 
  mutate(wt_h = wt_h/1000000,
         wt_w = wt_w/1000000) %>% 
  mutate(dpt1_crude = recode(dpt1,
                             "no" = 0,
                             "don't know" = 0,
                             "reported by mother" = 1,
                             "vaccination date on card" = 1,
                             "vaccination marked on card" = 1)) %>%
  mutate(dpt2_crude = recode(dpt2,
                             "no" = 0,
                             "don't know" = 0,
                             "reported by mother" = 1,
                             "vaccination date on card" = 1,
                             "vaccination marked on card" = 1)) %>%
  mutate(dpt3_crude = recode(dpt3,
                             "no" = 0,
                             "don't know" = 0,
                             "reported by mother" = 1,
                             "vaccination date on card" = 1,
                             "vaccination marked on card" = 1)) %>% 
  mutate(mcv1= recode(mcv1,
                         "no" = 0,
                         "don't know" = 0,
                         "reported by mother" = 1,
                         "vaccination date on card" = 1,
                         "vaccination marked on card" = 1)) %>% 
  mutate(bank = if_else(bank == "yes",1,0)) %>% 
  mutate(region= recode(region,
                        "north west" = 0,
                        "north east" = 1,
                        "north central" = 2,
                        "south east" = 3,
                        "south south" = 4,
                        "south west" = 5)) %>% 
  mutate(birth_int = if_else(birth_int<36,0,1)) %>%
  mutate(urban = recode(urban,
                        "rural" = 0,
                        "urban" = 1)) %>% 
  mutate(sex_child = recode(sex_child,
                            "male" = 0,
                            "female" = 1)) %>%
  mutate(birth_quarter= recode(birth_month,
                               "1" = 0,
                               "2" = 0,
                               "3" = 0,
                               "4" = 1,
                               "5" = 1,
                               "6" = 1,
                               "7" = 2,
                               "8" = 2,
                               "9" = 2,
                               "10" = 3,
                               "11" = 3,
                               "12" = 3)) %>%
  mutate(vit_a_recent = recode(vit_a_recent,
                               "no" = 0,
                               "don't know" = 0,
                               "reported by mother" = 1,
                               "vaccination date on card" = 1,
                               "vaccination marked on card" = 1)) %>% 
  mutate(health_card_doc = recode(health_card_doc,
                                  "does not have either card or other document" = 0,
                                  "has card/other document and none were seen" = 1,
                                  "has only health card and wasn't seen" = 1,
                                  "has only other document and wasn't seen" = 1,
                                  "has card/other document and both were seen" = 2,
                                  "has card/other document but only card was seen" = 2,
                                  "has card/other document but only other document was seen" = 2,
                                  "has only health card and was seen" = 2,
                                  "has only other document and was seen" = 2)) %>%
  mutate(sba = if_else( doctor == "yes" | nurse == "yes" | midwive == "yes", 1, 0)) %>% 
  mutate(newspaper= recode(newspaper,
                           "less than once a week" = 0,
                           "not at all" = 0,
                           "at least once a week" = 1),
         radio= recode(radio,
                       "less than once a week" = 0,
                       "not at all" = 0,
                       "at least once a week" = 1),
         tv= recode(tv,
                    "less than once a week" = 0,
                    "not at all" = 0,
                    "at least once a week" = 1),
         media= if_else(newspaper == 1 | radio == 1 | tv == 1, 1, 0)) %>% 
  mutate(educ = recode(educ,
                       "no education" = 0,
                       "primary" = 1,
                       "secondary" = 2,
                       "higher" = 2)) %>% 
  mutate(occup = recode(occup,
                        "agricultural" = 0,
                        "clerical" = 1,
                        "other" = 3,
                        "professional/technical/managerial" = 2,
                        "sales" = 1,
                        "services" = 1,
                        "skilled manual" = 3,
                        "unskilled manual" = 3)) %>% 
  mutate(Prob_get_advice = if_else(v467b=="big problem"|v467c=="big problem"|v467d=="big problem"
                                   |v467f=="big problem", 1,0)) %>%
  mutate(wealth = recode(wealth,
                         "poorest" = 0,
                         "poorer" = 0,
                         "middle" = 1,
                         "richer" = 2,
                         "richest" = 2)) %>% 
  mutate(m_age_grp= cut(m_age_w,
                        breaks = c(-Inf, 19, 29, 39, Inf),
                        labels = c(0, 1, 2, 3))) %>% 
  mutate(hhsize= cut(hhsize,
                     breaks = c(-Inf, 4, 8, Inf),
                     labels = c(2, 1, 0))) %>% 
  mutate(bord= cut(bord,
                   breaks = c(-Inf, 2, 5, Inf),
                   labels = c(0, 1, 2))) %>% 
  mutate(marital = recode(marital,
                          "never in union" = 0,
                          "married" = 1,
                          "living with partner" = 1,
                          "divorced" = 2,
                          "no longer living together/separated" = 2,
                          "widowed" = 2)) %>% 
  mutate(anc = cut(anc,
                   breaks = c(-Inf,0,3,Inf),
                   labels = c(0,1,2))) %>% 
  mutate(tt_bbirth= recode(tt_bbirth,
                           "0" = 0,
                           "1" = 1,
                           "2" = 1,
                           "3" = 2,
                           "4" = 2,
                           "5" = 3,
                           "6" = 3,
                           "7" = 3,
                           "8" = 3)) %>% 
  mutate(stunting = if_else(stunting < -2, 0, 1),
         wasting = if_else(wasting < -2, 0, 1),
         under_wt = if_else(under_wt < -2, 0, 1)) %>% 
  mutate(pnc= recode(pnc,
                     "no" = 0,
                     "yes" = 1,
                     "don't know" = 0)) %>% 
  mutate(employed_12m = recode(employed_12m,  
                               "no" = 1,
                               "currently working" = 0,
                               "have a job, but on leave last 7 days" = 0,
                               "in the past year" = 0)) %>% 
  mutate(religion_w = recode(religion_w,
                             "traditionalist" = 2,
                             "catholic" = 1,
                             "other christian" = 1,
                             "islam" = 0,
                             "other" = 2)) %>% 
  mutate(sex_hh= recode(sex_hh,
                        "male" = 1,
                        "female" = 0)) %>% 
  mutate(ethnicity = recode(ethnicity,
                            "ekoi" = 3,
                            "fulani" = 0,
                            "hausa" = 0,
                            "ibibio" = 3,
                            "igala" = 3,
                            "igbo" = 2,
                            "ijaw/izon" = 3,
                            "kanuri/beriberi" = 3,
                            "tiv" = 3,
                            "yoruba" = 1,
                            "other" = 3,
                            "don't know" = 3)) %>%
  mutate(m_phone = if_else(m_phone == "yes", 1,0)) %>%
  mutate(internet = recode(internet,
                           "never" = 0,
                           "yes, before last 12 months" = 1,
                           "yes, last 12 months" = 1)) %>% 
  mutate(phone_internet = if_else(m_phone==1 | internet==1, 1, 0)) %>%
  mutate(mal_cure = recode(mal_cure,
                           "disagree" = 0,
                           "don't know/not sure/depends" = 0,
                           "agree" = 1),
         mal_death = recode(mal_death,
                            "disagree" = 0,
                            "don't know/not sure/depends" = 0,
                            "agree" = 1),
         mal_know = if_else(mal_cure == 1|mal_death == 1, 1,0 )) %>%
  mutate(insurance = if_else(insurance  == "yes", 1,0)) %>% 
  mutate(land = recode(land,
                       "does not own" = 0,
                       "alone only" = 1,
                       "jointly only" = 1,
                       "both alone and jointly" = 1)) %>%
  mutate(own_bednet = if_else(own_bednet == "yes", 1,0),
         u5_bednet = recode(u5_bednet,
                            "no" = 0,
                            "all children" = 1,
                            "some children" = 1,
                            "no net in household" = 0)) %>% 
  mutate(length_stay = str_replace(length_stay, "always", "50"),
         length_stay = str_replace(length_stay, "visitor", "0"),
         length_stay = as.numeric(length_stay)) %>%
  mutate(decide_health = recode(decide_health,
                                "husband/partner alone" = 0,
                                "someone else" = 0,
                                "other" = 0,
                                "respondent alone" = 1,
                                "respondent and husband/partner" = 1)) %>% 
  mutate(decide_visit = recode(decide_visit,
                               "husband/partner alone" = 0,
                               "someone else" = 0,
                               "other" = 0,
                               "respondent alone" = 1,
                               "respondent and husband/partner" = 1)) %>% 
  mutate(decide_purchase = recode(decide_purchase,
                                  "husband/partner alone" = 0,
                                  "someone else" = 0,
                                  "other" = 0,
                                  "respondent alone" = 1,
                                  "respondent and husband/partner" = 1)) %>% 
  mutate(decision = if_else(decide_health == 1 & decide_visit == 1 & decide_purchase == 1, 1,0))


  #This part contains additional recoding for length_stay
  for(i in 1:nrow(nig)){
    if (nig$length_stay[i]==50) nig$length_stay[i] <- nig$m_age[i]
  }
  nig <- nig %>%
    mutate(length_stay = cut(length_stay,
                           breaks = c(-Inf,0,3,5,Inf), 
                           labels = c(0,1,2,3))) 

 #For selection of variables
  nig1 <- nig %>%
    select(cluster, hh_no, resp_no, midx, wt_h, wt_w, strat, #ID and weight
           dpt1_crude, dpt2_crude, dpt3_crude, mcv1,
           sex_child, bord, birth_int, health_card_doc, sba, anc, birth_quarter,
           tt_bbirth, pnc, vit_a_recent, 
           sex_hh, m_age_grp, marital, decision, Prob_get_advice, educ, religion_w, #Household level
           media, phone_internet, land, mal_know, occup, employed_12m, 
           insurance, own_bednet, u5_bednet, ethnicity, wealth, bank, hhsize, length_stay,
           urban, region #Cluster level
    )  

#Write file
write.csv(nig1, "nga_dhs_recoded.csv")

